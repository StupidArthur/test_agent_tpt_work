---
name: "fast-assert-missing-description-audit-20261007"
description_cn: "缺技术描述audit-20261007"
---

When explicitly invoked, reply exactly FAST_MINIMAL_OK. Do not use tools or external systems.
