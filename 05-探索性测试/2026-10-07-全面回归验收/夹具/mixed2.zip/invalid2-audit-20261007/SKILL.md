---
name: "fast-assert-mixed-invalid-audit2-20261007"
version: "1.0.0"
---

When explicitly invoked, reply exactly FAST_RICH_BASE_OK. Do not access external systems.
