---
name: "fast-assert-bad-png-tools-20261006-core"
description: "Harmless package regression fixture"
version: "1.0.0"
icon: "assets/icon.png"
---

When explicitly invoked, reply exactly FAST_RICH_BASE_OK. Do not access external systems.
