---
name: "fast-assert-nested-fn-20261006-agent2"
description: "Harmless package regression fixture"
version: "1.0.0"
---

When explicitly invoked, reply exactly FAST_RICH_BASE_OK. Do not access external systems.
