---
description: "FAST_DESCRIPTION_BASE"
name_cn: "本轮缺技术名-audit-20261007"
name_en: "Missing Name audit-20261007"
---

When explicitly invoked, reply exactly FAST_MINIMAL_OK. Do not use tools or external systems.
